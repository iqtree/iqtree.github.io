This folder contains 5690 sub-folders. Each of them is labelled with a distinctive number corresponding to a dataset in the PANDIT-based simulation of UFBoot2 paper.
In each subfolder, you will find 4 files:
+ ufboot2nni*treefile is the ML tree found by UFBoot2+NNI
+ ufboot2nni*contree is the majority-rule consensus tree of bootstrap trees found by UFBoot2+NNI
+ ufboot2.correct*treefile is the ML tree found by UFBoot2
+ ufboot2.correct*contree is the majority-rule consensus tree of bootstrap trees found by UFBoot2

Note that UFBoot2+NNI outputs are under severely violated model specification. UFBoot2 outputs are under correct model specification. For explanation about severely violated model and correctly specified model, please have a look at the UFBoot paper (Minh et al., 2013).


