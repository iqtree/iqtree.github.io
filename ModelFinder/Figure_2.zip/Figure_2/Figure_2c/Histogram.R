d <- read.csv("RF_distances_Wu.csv", header=T)
head(d)
pdf(height=3.0, width=4, file="RF_dist_Wu.pdf")
hist(d$RF, col="red", freq = TRUE, xlim=c(650,700), ylim=c(0,1000), xlab="RF", main="c")
dev.off()

