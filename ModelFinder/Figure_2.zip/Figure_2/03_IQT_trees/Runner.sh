#!/bin/bash
#SBATCH --job-name=IQT_WuFi
#SBATCH --time=80:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --mem=10000

module load iqtree

#Model used by Wu et al. (2009)
mkdir 01_WAG+IG5
cp concatenated.trimmed.fst ./01_WAG+IG5/.
cd 01_WAG+IG5
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m WAG+I+G5 -bb 10000 > README
cd ..
#Alternative model like that used by Wu et al. (2009)
mkdir 02_LG+IG5
cp concatenated.trimmed.fst ./02_LG+IG5/.
cd 02_LG+IG5
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m LG+I+G5 -bb 10000 > README
cd ..
#Model commonly used
mkdir 03_LG+IG4
cp concatenated.trimmed.fst ./03_LG+IG4/.
cd 03_LG+IG4
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m LG+I+G4 -bb 10000 > README
cd ..
#Model less commonly used
mkdir 04_LG+G4
cp concatenated.trimmed.fst ./04_LG+G4/.
cd 04_LG+G4
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m LG+G4 -bb 10000 > README
cd ..
#Our optimal model
mkdir 05_LG+R14
cp concatenated.trimmed.fst ./05_LG+R14/.
cd 05_LG+R14
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m LG+R14 -bb 10000 > README
cd ..
#Our alternative model
mkdir 06_LG+G14
cp concatenated.trimmed.fst ./06_LG+G14/.
cd 06_LG+G14
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m LG+G14 -bb 10000 > README
cd ..

