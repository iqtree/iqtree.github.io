#!/bin/bash
#SBATCH --job-name=IQT_WuFi
#SBATCH --time=12:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --mem=8000
#SBATCH --array=0-49

module load iqtree

#Our optimal model
j=$SLURM_ARRAY_TASK_ID 
mkdir $j
cp concatenated.trimmed.fst ./$j/
cp Six_Trees.nwk ./$j/
cd $j
iqtree -s concatenated.trimmed.fst -st AA -nt 2 -m LG+R14 -n 0 -z Six_Trees.nwk -zb 10000 > README

