#!/bin/bash
#SBATCH --job-name=MFA_Wu
#SBATCH --time=90:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=10
#SBATCH --mem=10000

module load iqtree

iqtree -s concatenated.trimmed.fst -st AA -nt 10 -m MF -msub nuclear -cmax 20 -mtree > README
