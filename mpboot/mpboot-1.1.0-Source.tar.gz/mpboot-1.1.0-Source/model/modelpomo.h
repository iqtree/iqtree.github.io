/*
 * modelpomo.h
 *
 *  Created on: Mar 25, 2014
 *      Author: minh
 */

#ifndef MODELPOMO_H_
#define MODELPOMO_H_

#include "modelgtr.h"

class ModelPoMo: public ModelGTR {
public:
	ModelPoMo();
	virtual ~ModelPoMo();
};

#endif /* MODELPOMO_H_ */
