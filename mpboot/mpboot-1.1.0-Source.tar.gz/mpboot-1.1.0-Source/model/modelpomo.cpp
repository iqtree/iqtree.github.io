/*
 * modelpomo.cpp
 *
 *  Created on: Mar 25, 2014
 *      Author: minh
 */

#include "modelpomo.h"

ModelPoMo::ModelPoMo() {
	// TODO Auto-generated constructor stub

}

ModelPoMo::~ModelPoMo() {
	// TODO Auto-generated destructor stub
}

