/*
 *  phylolib.h
 *
 *  Created on: Nov 19, 2012
 *  Author: tung
 */

#ifndef PHYLOLIB_H_
#define PHYLOLIB_H_

//#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif



#endif /* PHYLOLIB_H_ */
