/*
 * phylotreeeigen.cpp
 *
 *  Created on: Sep 15, 2014
 *      Author: minh
 */



#include "phylotree.h"
#include "modelgtr.h"
